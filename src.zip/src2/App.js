import "./App.css";
import RouteFile from "./Components/RouteFile";
import NavBar from "./Navitagtion/NavBar";
function App() {
  return (
    <div className="App">
      <NavBar />
      <RouteFile />
    </div>
  );
}

export default App;
