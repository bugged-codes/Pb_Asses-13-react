import React from "react";

const PageNotFound = () => {
  return (
    <div>
      <span style={{ color: "red" }}> PageNotFound : Error 404 </span>
    </div>
  );
};

export default PageNotFound;
